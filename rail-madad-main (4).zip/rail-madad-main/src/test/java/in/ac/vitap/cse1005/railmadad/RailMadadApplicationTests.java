package in.ac.vitap.cse1005.railmadad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailMadadApplicationTests {

  @Test
  void contextLoads() {}
}
